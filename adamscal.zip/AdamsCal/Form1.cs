﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace AdamsCal
{
    public partial class Form1 : Form
    {
        string GenOperator = "";
        bool isGenOperators = false;
        double GenResult = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (isGenOperators))
            {
                textBox1.Clear();
            }
            Button button = (Button)sender;
            label1.Text += button.Text;
            textBox1.Text = textBox1.Text + button.Text;

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (isGenOperators))
            {
                textBox1.Clear();
            }
            Button button = (Button)sender;
            label1.Text += button.Text;
            textBox1.Text = textBox1.Text + button.Text;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (isGenOperators))
            {
                textBox1.Clear();
            }
            Button button = (Button)sender;
            label1.Text += button.Text;
            textBox1.Text = textBox1.Text + button.Text;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            string TextBoxx = textBox1.Text;
            string check_dot = ".";
            bool check_dot2 = TextBoxx.Contains(check_dot);

            if (textBox1.Text == "0")
            {
                Button button = (Button)sender;
                label1.Text += button.Text;
                //textBox1.Clear();
                textBox1.Text = "0.";
            }
            else if (isGenOperators)
            {
                textBox1.Clear();
            }

            else if (check_dot2 == true)
            {
                Button button = (Button)sender;
                label1.Text += button.Text;
                textBox1.Text = textBox1.Text + "";
            }
            else{
                //use this or the code below   textBox1.Text = textBox1.Text + ".";
                Button button = (Button)sender;
                label1.Text += button.Text;
                textBox1.Text = textBox1.Text + button.Text;
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {

            if ((textBox1.Text == "0") || (isGenOperators))
            {
                textBox1.Clear();
            }
            Button button = (Button)sender;
            label1.Text += button.Text;
            textBox1.Text = textBox1.Text + button.Text;


        }

        private void button10_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (isGenOperators))
            {
                textBox1.Clear();
            }
            Button button = (Button)sender;
            label1.Text += button.Text;
            textBox1.Text = textBox1.Text + button.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (isGenOperators))
            {
                textBox1.Clear();
            }
            Button button = (Button)sender;
            label1.Text += button.Text;
            textBox1.Text = textBox1.Text + button.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (isGenOperators))
            {
                textBox1.Clear();
            }
            Button button = (Button)sender;
            label1.Text += button.Text;
            textBox1.Text = textBox1.Text + button.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (isGenOperators))
            {
                textBox1.Clear();
            }
            //use this or the code below   textBox1.Text = textBox1.Text + "7";
            Button button = (Button)sender;
            label1.Text += button1.Text;
            textBox1.Text = textBox1.Text + button1.Text;
           // string remove_last_cha7 = textBox1.Text.Substring(label1.Text.Length - 1, 1);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (isGenOperators))
            {
                textBox1.Clear();
            }
            //use this or the code below   textBox1.Text = textBox1.Text + "8";
            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + button2.Text;
            label1.Text +=  button2.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (isGenOperators))
            {
                textBox1.Clear();
            }
            //use this or the code below   textBox1.Text = textBox1.Text + "9";
            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + button3.Text;
            label1.Text += button3.Text;
            // GenResult = Double.Parse(textBox1.Text);
            //label1.Text = GenResult.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text = "0";
            label1.Text="";
            GenOperator = "";
            GenResult = 0;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button23_Click(object sender, EventArgs e)
        {
            string full_cha = textBox1.Text;
             
            
            if (full_cha != "0" && full_cha != "")
            {
                string remove_last_cha = full_cha.Remove(full_cha.Length - 1, 1);
                textBox1.Text = remove_last_cha;
            }
            
            else if (full_cha == "")
            {
                textBox1.Text = "0";
            }


        }

        private void button22_Click(object sender, EventArgs e)
        {

            try
            {
                
                label1.Text = "Square Root: (" +  textBox1.Text +")";
                textBox1.Text = (Math.Sqrt(Double.Parse(textBox1.Text))).ToString();
            }
            catch (Exception)
            {
                textBox1.Text = "0";
            }

//            textBox1.Text = (Math.Sqrt(Double.Parse(textBox1.Text))).ToString() ;
            //  Button button = (Button)sender;
            //            textBox1.Text =  (textBox1.Text) ;
            //string sqRoot = Convert.ToInt32(squareroot_);
            //textBox1.Text = float Math.Sqrt(squareroot_);

        }

        private void button21_Click(object sender, EventArgs e)
        {

            try
            {
                label1.Text = "SIN: (" + textBox1.Text + ")";
                textBox1.Text = (Math.Sin(Double.Parse(textBox1.Text))).ToString();
            }
            catch (Exception)
            {
                textBox1.Text = "0";
            }
             
        }

        private void button19_Click(object sender, EventArgs e)
        {
            

            try
            {
                label1.Text = "TAN: (" + textBox1.Text + ")";
                textBox1.Text = (Math.Cos(Double.Parse(textBox1.Text))).ToString();
            }
            catch (Exception)
            {
                textBox1.Text = "0";
            }


        }

        //DIVISION
        private void button4_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            if (GenResult != 0)
            {
                button16.PerformClick();
                GenOperator = button.Text;
                label1.Text = GenResult + " " + GenOperator;
                isGenOperators = true;
            }

            else

            {
                GenOperator = button.Text;
                GenResult = Double.Parse(textBox1.Text);
                label1.Text = GenResult + " " + GenOperator;
                isGenOperators = true;
            }


        }

        private void button16_Click(object sender, EventArgs e)
        {
           
            switch (GenOperator)
            {
                case "+":
                    textBox1.Text = (GenResult + Double.Parse(textBox1.Text)).ToString();
                    
                    break;
                case "-":
                    textBox1.Text = (GenResult - Double.Parse(textBox1.Text)).ToString();
                    break;
                case "/":
                    textBox1.Text = (GenResult / Double.Parse(textBox1.Text)).ToString();
                    
                    break;
                case "*":
                    textBox1.Text = (GenResult * Double.Parse(textBox1.Text)).ToString();
                    break;
                default:
                    break;
            }

            GenResult = Double.Parse(textBox1.Text);
            label1.Text = "";
           
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
           
            Button button = (Button)sender;
            if (GenResult != 0)
            {
                button16.PerformClick();
                GenOperator = button.Text;
                label1.Text = GenResult + " " + GenOperator;
                isGenOperators = true;
            }

            else

            {
                GenOperator = button.Text;
                GenResult = Double.Parse(textBox1.Text);
                label1.Text = GenResult + " " + GenOperator;
                isGenOperators = true;
            }

        }

        private void button12_Click(object sender, EventArgs e)
        {
            
            Button button = (Button)sender;
            if (GenResult != 0)
            {
                button16.PerformClick();
                GenOperator = button.Text;
                label1.Text = GenResult + " " + GenOperator;
                isGenOperators = true;
            }

            else

            {
                GenOperator = button.Text;
                GenResult = Double.Parse(textBox1.Text);
                label1.Text = GenResult + " " + GenOperator;
                isGenOperators = true;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            if(GenResult != 0)
            {
                button16.PerformClick();
                GenOperator = button.Text;
                label1.Text = GenResult + " " + GenOperator;
                isGenOperators = true;
            }
            
            else
            
            {
                GenOperator = button.Text;
                GenResult = Double.Parse(textBox1.Text);
                label1.Text = GenResult + " " + GenOperator;
                isGenOperators = true;
            }

            
            
        }

        private void transparentToolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
